# https://www.lanqiao.cn/problems/594/learning/
# 参考答案：761

def print_out(lst):
    # 一行行输出
    for line in lst:
        for x in line:
            print("%04d" % x,end=" ")
        # print(" ".join(map(str, i)))
        print()


lst = [i for i in range(1000)]

num = 1

res = [[0 for i in range(101)] for i in range(101)]

i, j = 0, 0

# 
res[0][0] = num
while i != 100 and j != 100:
    num += 1
    # 向右
    j += 1
    res[i][j] = num
    while j > 0:
        # 向斜左下角
        num += 1
        i += 1
        j -= 1
        res[i][j] = num
    num += 1
    # 向下
    i += 1
    res[i][j] = num
    while i > 0:
        # 向斜右上角
        num += 1
        i -= 1
        j += 1
        res[i][j] = num

# 蛇形填数字
with open ('./out.txt','w+') as fp:
    for line in res:
        for x in line:
            fp.write("%04d " % x)
        fp.write("\n")