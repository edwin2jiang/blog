# https://www.lanqiao.cn/problems/507/learning/

import os
import sys

s = []
r = []
m = []

for i in range(6):
    s.append(list(map(int, input().split())))
n = int(input())
for i in range(n):
    r.append(list(map(int, input().split())))
for i in range(6):
    p = s[i]
    for j in range(n):
        if i == 0:
            m.append(p[1:].count(int(j+1)))
        else:
            m[j] += p[1:].count(int(j+1))

'''print(m)''' '''用m[j]记录6件装备共有 j+1级孔m[j]个'''
mm = m
'''假设j级孔全用j级珠子'''
up = []
down = []
'''up记录加一颗珠子提升的价值，down记录少一颗珠子减少的价值'''


def up1(k):
    if mm[k] >= r[k][1]:
        return 0
    elif mm[k] == 0:
        return r[k][2]
    else:
        return r[k][2+mm[k]]-r[k][1+mm[k]]


def down1(k):
    if mm[k] == 1:
        return r[k][2]
    elif mm[k] > r[k][1]:
        return 0
    else:
        return r[k][1+mm[k]]-r[k][mm[k]]


for i in range(n):
    up.append(up1(i))
    down.append(down1(i))

'''print(up,down)'''
'''第n+1级孔，如果1到n级孔中珠子加1的价值比它减少1颗的价值大，则数值各加1、减1，up、down更新'''


def main1(n):
    if n == 0:
        return
    while max(up[:n]) > down[n] and mm[n] > 0:
        t = up.index(max(up[:n]))
        mm[t] += 1
        up[t] = up1(t)
        mm[n] -= 1
        down[n] = down1(n)
    main1(n-1)
    return


point = 0
main1(n-1)
'''输入有n级，为了和形参统一，此处减1'''
'''print(up,down)
print(mm)'''
for i in range(n):
    if mm[i] != 0:
        point += r[i][1+mm[i]]
print(point)
'''得到总价值'''
