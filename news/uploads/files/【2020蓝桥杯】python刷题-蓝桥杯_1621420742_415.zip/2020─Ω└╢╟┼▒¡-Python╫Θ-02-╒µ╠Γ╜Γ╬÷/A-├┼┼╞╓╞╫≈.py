# https://www.lanqiao.cn/problems/592/learning/
# 参考答案：624


total = 0
for i in range(1,2021):
    total += (str(i).count("2"))

print(total)

# 624
