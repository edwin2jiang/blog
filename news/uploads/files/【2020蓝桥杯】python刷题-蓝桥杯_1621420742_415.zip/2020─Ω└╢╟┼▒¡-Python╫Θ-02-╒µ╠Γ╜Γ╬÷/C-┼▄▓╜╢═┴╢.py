# https://www.lanqiao.cn/problems/597/learning/
# 参考答案：8879

flag = 6

def nextDay(date):
    '''
    date: 格式 yyyy-mm-dd
    return next_date,is_monday,is_month_begin
    星期一和月初
    '''
    date = list(map(int,date.split("-")))
    y,m,d = date

    d+=1

    if m == 12 and d == 32:
        y += 1
        m = 1
        d = 1
    elif m == 2:
        if is_leap_year(y):
            if d == 30:
                m = 3
                d = 1
        else:
            if d == 29:
                m = 3
                d = 1
    elif is_big_month(m):
        if d == 32:
            m += 1
            d = 1
    elif not is_big_month(m):
        if d == 31:
            m += 1
            d = 1

    global flag
    add_week()
    
    is_month_begin = True if d == 1 else False
    is_monday = True if flag == 1 else False

    new_date = "%d-%02d-%02d" % (y,m,d)
    return new_date,is_monday,is_month_begin
            
    

def is_leap_year(year):
    if year % 4 == 0 and year % 100 != 0:
        return True
    elif year % 400 == 0:
        return True
    return False

def is_big_month(month):
    if month in [1,3,5,7,8,10,12]:
        return True
    else:
        return False

def add_week():
    global flag
    flag = (flag + 1) % 8 if (flag + 1) % 8 else 1


def main():
    start_time = "2000-01-01"
    # end_time = "2000-01-10"
    end_time = "2020-10-01"
    total = 2
    while start_time != end_time:
        start_time,is_monday,is_month_begin = nextDay(start_time)
        if is_monday or is_month_begin:
            total += 2
        else:
            total += 1
        print(start_time,is_monday,is_month_begin,total)
    print(total)
    # ans = 
    
main()
