# 【2020蓝桥杯】Python组真题 - 第十一届蓝桥杯

```
本资料整理者&代码编写者：夏2同学
个人邮箱：1754082565@qq.com
请勿未经同意转载 & 如有错误，欢迎指正
```
## A-门牌制作.py
题目地址：# https://www.lanqiao.cn/problems/592/learning/



### 参考答案：624

```python
# https://www.lanqiao.cn/problems/592/learning/
 # 参考答案：624
 
 
 total = 0
 for i in range(1,2021):
     total += (str(i).count("2"))
 
 print(total)
 
 # 624
```

## B-寻找2020.py
题目地址：# 无在线练习题地址

### 参考答案：16520

```python
# 无在线练习题地址
 # 参考答案：16520
 
 def search_row(l):
     res = 0
     m = len(l[0])
     n = len(l)
     for i in range(n):
         for j in range(m-3):
             if l[i][j] == "2" and l[i][j+1] == "0" \
                and l[i][j+2] == "2" and l[i][j+3] == "0":
                 res += 1
     return res
 
 
 def search_xie(l):
     res = 0
     m = len(l[0])
     n = len(l)
     for i in range(n-3):
         for j in range(m-3):
             if l[i][j] == "2" and l[i+1][j+1] == "0" \
                and l[i+2][j+2] == "2" and l[i+3][j+3] == "0":
                 res += 1
     return res
 
 
 def search_col(l):
     res = 0
     m = len(l[0])
     n = len(l)
     for j in range(m):
         for i in range(n-3):
             if l[i][j] == "2" and l[i+1][j] == "0" \
                and l[i+2][j] == "2" and l[i+3][j] == "0":
                 res += 1    
     return res
 
 
 
 with open("2020.txt",'r') as fp:
     lines = fp.readlines()
     i = 0
     for line in lines:
         lines[i] = line.strip('\n')
         i+=1
 
     # 16520
     print(search_row(lines)+search_xie(lines)+search_col(lines))
 
 
```

## C-跑步锻炼.py
题目地址：# https://www.lanqiao.cn/problems/597/learning/

### 参考答案：8879

```python
# https://www.lanqiao.cn/problems/597/learning/
 # 参考答案：8879
 
 flag = 6
 
 def nextDay(date):
     '''
     date: 格式 yyyy-mm-dd
     return next_date,is_monday,is_month_begin
     星期一和月初
     '''
     date = list(map(int,date.split("-")))
     y,m,d = date
 
     d+=1
 
     if m == 12 and d == 32:
         y += 1
         m = 1
         d = 1
     elif m == 2:
         if is_leap_year(y):
             if d == 30:
                 m = 3
                 d = 1
         else:
             if d == 29:
                 m = 3
                 d = 1
     elif is_big_month(m):
         if d == 32:
             m += 1
             d = 1
     elif not is_big_month(m):
         if d == 31:
             m += 1
             d = 1
 
     global flag
     add_week()
     
     is_month_begin = True if d == 1 else False
     is_monday = True if flag == 1 else False
 
     new_date = "%d-%02d-%02d" % (y,m,d)
     return new_date,is_monday,is_month_begin
             
     
 
 def is_leap_year(year):
     if year % 4 == 0 and year % 100 != 0:
         return True
     elif year % 400 == 0:
         return True
     return False
 
 def is_big_month(month):
     if month in [1,3,5,7,8,10,12]:
         return True
     else:
         return False
 
 def add_week():
     global flag
     flag = (flag + 1) % 8 if (flag + 1) % 8 else 1
 
 
 def main():
     start_time = "2000-01-01"
     # end_time = "2000-01-10"
     end_time = "2020-10-01"
     total = 2
     while start_time != end_time:
         start_time,is_monday,is_month_begin = nextDay(start_time)
         if is_monday or is_month_begin:
             total += 2
         else:
             total += 1
         print(start_time,is_monday,is_month_begin,total)
     print(total)
     # ans = 
     
 main()
```

## D-蛇形填数.py
题目地址：# https://www.lanqiao.cn/problems/594/learning/

### 参考答案：761

```python
# https://www.lanqiao.cn/problems/594/learning/
 # 参考答案：761
 
 def print_out(lst):
     # 一行行输出
     for line in lst:
         for x in line:
             print("%04d" % x,end=" ")
         # print(" ".join(map(str, i)))
         print()
 
 
 lst = [i for i in range(1000)]
 
 num = 1
 
 res = [[0 for i in range(101)] for i in range(101)]
 
 i, j = 0, 0
 
 # 
 res[0][0] = num
 while i != 100 and j != 100:
     num += 1
     # 向右
     j += 1
     res[i][j] = num
     while j > 0:
         # 向斜左下角
         num += 1
         i += 1
         j -= 1
         res[i][j] = num
     num += 1
     # 向下
     i += 1
     res[i][j] = num
     while i > 0:
         # 向斜右上角
         num += 1
         i -= 1
         j += 1
         res[i][j] = num
 
 # 蛇形填数字
 with open ('./out.txt','w+') as fp:
     for line in res:
         for x in line:
             fp.write("%04d " % x)
         fp.write("\n")``` 

## E-排序.py
题目地址：# https://www.lanqiao.cn/problems/598/learning/

### 参考答案：jonmlkihgfedcba

​```python
# https://www.lanqiao.cn/problems/598/learning/
 # 参考答案：jonmlkihgfedcba
 
 import random
 
 count = 0
 
 # def bubble_sort(lst):
 #     n = len(lst)
 #     for i in range(n-1):
 #         # is_ordered = True
 #         j = 0
 #         while j < n-i-1:
 #             if lst[j] > lst[j+1]:
 #                 # 交换
 #                 lst[j], lst[j+1] = lst[j+1], lst[j]
 #                 global count
 #                 count += 1
 #                 # is_ordered = False
 #             j += 1
 
 def bubble_sort(lst):
     n = len(lst)
     for i in range(n-1):
         is_ordered = True
         j = 0
         while j < n-i-1:
             if lst[j] > lst[j+1]:
                 # 交换
                 lst[j], lst[j+1] = lst[j+1], lst[j]
                 global count
                 count += 1
                 is_ordered = False
             j += 1
         if is_ordered:
             # 结束冒泡
             break
             
 
 # string =[chr(i) for i in range(ord('a'),ord('p'))]
 
 # data = ['o', 'n', 'm', 'l', 'k', 'j',
 #         'i', 'h', 'g', 'f', 'e', 'd', 'c', 'b', 'a']
 
 # 1. 最短 2. 字典序低
 
 data = ['j', 'o', 'n', 'm', 'l', 'k',
         'i', 'h', 'g', 'f', 'e', 'd', 'c', 'b', 'a']
 
 # data = string[::-1]
 
 print(data)
 bubble_sort(data)
 print(data)
 print(count)
```

## F-成绩统计.py
题目地址：# https://www.lanqiao.cn/problems/502/learning



```python
# https://www.lanqiao.cn/problems/502/learning
 
 from decimal import *
 
 n = int(input())
 
 socres = [int(input()) for i in range(n)]
 
 youxiu = 0
 jige = 0
 
 for i in socres:
     if i >= 85:
         youxiu += 1
     if i >= 60:
         jige += 1
 
 # 高精度
 percent1 = int(round(float(Decimal(jige) / Decimal(n)) * 100, 0))
 percent2 = int(round(float(Decimal(youxiu) / Decimal(n)) * 100, 0))
 
 print("%d%%" % percent1)
 print("%d%%" % percent2)
```

## G-单词分析.py
题目地址：# https://www.lanqiao.cn/problems/504/learning



```python
# https://www.lanqiao.cn/problems/504/learning
 
 # 记录26个英文字母的顺序
 charLst = [0] * 26
 
 string = input()
 
 for char in string:
     charLst[ord(char)-97] += 1
 
 max_value = max(charLst)
 res_index = charLst.index(max_value)
 res_chr = chr(res_index + 97)
 
 print(res_chr)
 print(max_value)
```

## H-数字三角形.py
题目地址：# https://www.lanqiao.cn/problems/505/learning/



```python
# https://www.lanqiao.cn/problems/505/learning/
 
 # 借鉴了 https://www.jianshu.com/p/c20b6b9a178a （C++）
 
 
 if __name__ == '__main__':
     # MAX = 105
     n = int(input())
     MAX = n+2
     nums = [[0 for i in range(1, MAX)] for i in range(1, MAX)]
     dp = [[0 for i in range(1, MAX)] for i in range(1, MAX)]
 
     # 读取用户输入
     for i in range(1, n+1):
         line = map(int, input().split(" "))
         for j, e in enumerate(line):
             nums[i][j+1] = e
 
     # print(nums)
 
     # 初始化最后一行
     if n % 2 == 0:
         dp[n][n//2] = nums[n][n//2]
         dp[n][n//2 + 1] = nums[n][n//2 + 1]
     else:
         dp[n][n//2 + 1] = nums[n][n//2 + 1]
 
     # 从后往前依次遍历
     for i in range(n-1, 0, -1):
         for j in range(1, i+1):
             # 如果下一行左边或者右边不为0
             if dp[i+1][j] != 0 or dp[i+1][j+1] != 0:
                 dp[i][j] = nums[i][j] + max(dp[i+1][j], dp[i+1][j+1])
 
     print(dp[1][1])
```

## I-平面分割.py
题目地址：# https://www.lanqiao.cn/problems/503/learning/



```python
# https://www.lanqiao.cn/problems/503/learning/
 
 # 思路：画几张图观察一下可以发现一下特点：
 # 1、重边不会影响区域数目。
 # 2、每新加入一条边只要不是重边区域数目必定+1。
 # 3、加入的新边如果与之前加入的边每有一个交点则区域数目+1。
 
 n = int(input())
 
 # 存放直线数（必须得不重合）
 set_line = set()
 # 存放交点数
 set_point = set()
 
 for i in range(n):
     tmp = tuple(input().split())
     set_line.add(tmp)
     set_point.add(tmp[0])
 
 
 print(len(set_line)+len(set_point))
 
```

## J-装饰珠.py
题目地址：# https://www.lanqiao.cn/problems/507/learning/



```python
# https://www.lanqiao.cn/problems/507/learning/
 
 import os
 import sys
 
 s = []
 r = []
 m = []
 
 for i in range(6):
     s.append(list(map(int, input().split())))
 n = int(input())
 for i in range(n):
     r.append(list(map(int, input().split())))
 for i in range(6):
     p = s[i]
     for j in range(n):
         if i == 0:
             m.append(p[1:].count(int(j+1)))
         else:
             m[j] += p[1:].count(int(j+1))
 
 '''print(m)''' '''用m[j]记录6件装备共有 j+1级孔m[j]个'''
 mm = m
 '''假设j级孔全用j级珠子'''
 up = []
 down = []
 '''up记录加一颗珠子提升的价值，down记录少一颗珠子减少的价值'''
 
 
 def up1(k):
     if mm[k] >= r[k][1]:
         return 0
     elif mm[k] == 0:
         return r[k][2]
     else:
         return r[k][2+mm[k]]-r[k][1+mm[k]]
 
 
 def down1(k):
     if mm[k] == 1:
         return r[k][2]
     elif mm[k] > r[k][1]:
         return 0
     else:
         return r[k][1+mm[k]]-r[k][mm[k]]
 
 
 for i in range(n):
     up.append(up1(i))
     down.append(down1(i))
 
 '''print(up,down)'''
 '''第n+1级孔，如果1到n级孔中珠子加1的价值比它减少1颗的价值大，则数值各加1、减1，up、down更新'''
 
 
 def main1(n):
     if n == 0:
         return
     while max(up[:n]) > down[n] and mm[n] > 0:
         t = up.index(max(up[:n]))
         mm[t] += 1
         up[t] = up1(t)
         mm[n] -= 1
         down[n] = down1(n)
     main1(n-1)
     return
 
 
 point = 0
 main1(n-1)
 '''输入有n级，为了和形参统一，此处减1'''
 '''print(up,down)
 print(mm)'''
 for i in range(n):
     if mm[i] != 0:
         point += r[i][1+mm[i]]
 print(point)
 '''得到总价值'''
```
