# 无在线练习题地址
# 参考答案：16520

def search_row(l):
    res = 0
    m = len(l[0])
    n = len(l)
    for i in range(n):
        for j in range(m-3):
            if l[i][j] == "2" and l[i][j+1] == "0" \
               and l[i][j+2] == "2" and l[i][j+3] == "0":
                res += 1
    return res


def search_xie(l):
    res = 0
    m = len(l[0])
    n = len(l)
    for i in range(n-3):
        for j in range(m-3):
            if l[i][j] == "2" and l[i+1][j+1] == "0" \
               and l[i+2][j+2] == "2" and l[i+3][j+3] == "0":
                res += 1
    return res


def search_col(l):
    res = 0
    m = len(l[0])
    n = len(l)
    for j in range(m):
        for i in range(n-3):
            if l[i][j] == "2" and l[i+1][j] == "0" \
               and l[i+2][j] == "2" and l[i+3][j] == "0":
                res += 1    
    return res



with open("2020.txt",'r') as fp:
    lines = fp.readlines()
    i = 0
    for line in lines:
        lines[i] = line.strip('\n')
        i+=1

    # 16520
    print(search_row(lines)+search_xie(lines)+search_col(lines))


