# https://www.lanqiao.cn/problems/504/learning

# 记录26个英文字母的顺序
charLst = [0] * 26

string = input()

for char in string:
    charLst[ord(char)-97] += 1

max_value = max(charLst)
res_index = charLst.index(max_value)
res_chr = chr(res_index + 97)

print(res_chr)
print(max_value)
