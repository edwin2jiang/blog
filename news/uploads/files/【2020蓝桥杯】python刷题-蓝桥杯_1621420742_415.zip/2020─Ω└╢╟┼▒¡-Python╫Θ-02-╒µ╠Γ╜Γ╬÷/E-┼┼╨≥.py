# https://www.lanqiao.cn/problems/598/learning/
# 参考答案：jonmlkihgfedcba

import random

count = 0

# def bubble_sort(lst):
#     n = len(lst)
#     for i in range(n-1):
#         # is_ordered = True
#         j = 0
#         while j < n-i-1:
#             if lst[j] > lst[j+1]:
#                 # 交换
#                 lst[j], lst[j+1] = lst[j+1], lst[j]
#                 global count
#                 count += 1
#                 # is_ordered = False
#             j += 1

def bubble_sort(lst):
    n = len(lst)
    for i in range(n-1):
        is_ordered = True
        j = 0
        while j < n-i-1:
            if lst[j] > lst[j+1]:
                # 交换
                lst[j], lst[j+1] = lst[j+1], lst[j]
                global count
                count += 1
                is_ordered = False
            j += 1
        if is_ordered:
            # 结束冒泡
            break
            

# string =[chr(i) for i in range(ord('a'),ord('p'))]

# data = ['o', 'n', 'm', 'l', 'k', 'j',
#         'i', 'h', 'g', 'f', 'e', 'd', 'c', 'b', 'a']

# 1. 最短 2. 字典序低

data = ['j', 'o', 'n', 'm', 'l', 'k',
        'i', 'h', 'g', 'f', 'e', 'd', 'c', 'b', 'a']

# data = string[::-1]

print(data)
bubble_sort(data)
print(data)
print(count)
