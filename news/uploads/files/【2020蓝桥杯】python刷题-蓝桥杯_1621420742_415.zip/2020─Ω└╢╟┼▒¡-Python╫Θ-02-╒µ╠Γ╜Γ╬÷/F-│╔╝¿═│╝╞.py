# https://www.lanqiao.cn/problems/502/learning

from decimal import *

n = int(input())

socres = [int(input()) for i in range(n)]

youxiu = 0
jige = 0

for i in socres:
    if i >= 85:
        youxiu += 1
    if i >= 60:
        jige += 1

# 高精度
percent1 = int(round(float(Decimal(jige) / Decimal(n)) * 100, 0))
percent2 = int(round(float(Decimal(youxiu) / Decimal(n)) * 100, 0))

print("%d%%" % percent1)
print("%d%%" % percent2)
