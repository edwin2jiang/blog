# https://www.lanqiao.cn/problems/503/learning/

# 思路：画几张图观察一下可以发现一下特点：
# 1、重边不会影响区域数目。
# 2、每新加入一条边只要不是重边区域数目必定+1。
# 3、加入的新边如果与之前加入的边每有一个交点则区域数目+1。

n = int(input())

# 存放直线数（必须得不重合）
set_line = set()
# 存放交点数
set_point = set()

for i in range(n):
    tmp = tuple(input().split())
    set_line.add(tmp)
    set_point.add(tmp[0])


print(len(set_line)+len(set_point))

