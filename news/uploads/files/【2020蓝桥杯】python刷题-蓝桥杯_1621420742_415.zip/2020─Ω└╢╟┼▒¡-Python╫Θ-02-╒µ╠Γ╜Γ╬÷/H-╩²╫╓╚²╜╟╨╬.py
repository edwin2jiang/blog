# https://www.lanqiao.cn/problems/505/learning/

# 借鉴了 https://www.jianshu.com/p/c20b6b9a178a （C++）


if __name__ == '__main__':
    # MAX = 105
    n = int(input())
    MAX = n+2
    nums = [[0 for i in range(1, MAX)] for i in range(1, MAX)]
    dp = [[0 for i in range(1, MAX)] for i in range(1, MAX)]

    # 读取用户输入
    for i in range(1, n+1):
        line = map(int, input().split(" "))
        for j, e in enumerate(line):
            nums[i][j+1] = e

    # print(nums)

    # 初始化最后一行
    if n % 2 == 0:
        dp[n][n//2] = nums[n][n//2]
        dp[n][n//2 + 1] = nums[n][n//2 + 1]
    else:
        dp[n][n//2 + 1] = nums[n][n//2 + 1]

    # 从后往前依次遍历
    for i in range(n-1, 0, -1):
        for j in range(1, i+1):
            # 如果下一行左边或者右边不为0
            if dp[i+1][j] != 0 or dp[i+1][j+1] != 0:
                dp[i][j] = nums[i][j] + max(dp[i+1][j], dp[i+1][j+1])

    print(dp[1][1])
