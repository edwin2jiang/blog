import os


files = ['A-门牌制作.py', 'B-寻找2020.py', 'C-跑步锻炼.py', 'D-蛇形填数.py',
         'E-排序.py', 'F-成绩统计.py', 'G-单词分析.py', 'H-数字三角形.py', 'I-平面分割.py', 'J-装饰珠.py']

fs = open('./README.md', 'a', encoding='utf-8')

for title in files:
    this = open(title, 'r', encoding='utf-8')
    lines = this.readlines()
    content = f'\n## {title}\n题目地址：{lines[0]}\n##{lines[1]}\n```python\n{" ".join(lines)}``` \n'
    fs.write(content)
